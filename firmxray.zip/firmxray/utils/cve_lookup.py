import requests

class CVELookup:
    def search_cve(self, product):
        try:
            url = f"https://cve.circl.lu/api/search/{product}"
            response = requests.get(url)
            return response.json()
        except Exception:
            return {}
