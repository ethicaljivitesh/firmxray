import json
from jinja2 import Template

class ReportGenerator:
    def generate_json(self, report, filename):
        with open(filename, 'w') as f:
            json.dump(report, f, indent=4)

    def generate_html(self, report, filename):
        html_template = '''
        <html><head><title>Firmware Report</title></head>
        <body><h1>Firmware Analysis Report</h1>
        <pre>{{ report | tojson(indent=4) }}</pre>
        </body></html>
        '''
        tmpl = Template(html_template)
        with open(filename, 'w') as f:
            f.write(tmpl.render(report=report))
