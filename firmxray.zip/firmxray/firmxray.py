# firmxray.py
import argparse
import os
import subprocess
import hashlib
import json
import re
import shutil
from utils.cve_lookup import CVELookup
from analyzers.extractor import FirmwareExtractor
from analyzers.filesystem_scanner import FileSystemScanner
from analyzers.binary_analyzer import BinaryAnalyzer
from analyzers.crypto_scanner import CryptoScanner
from analyzers.network_parser import NetworkServiceParser
from utils.report_generator import ReportGenerator

def hash_file(path):
    sha1 = hashlib.sha1()
    with open(path, 'rb') as f:
        while True:
            data = f.read(65536)
            if not data:
                break
            sha1.update(data)
    return sha1.hexdigest()

def main():
    parser = argparse.ArgumentParser(description='FirmX-Ray - Advanced Firmware Analysis Tool')
    parser.add_argument('-f', '--firmware', required=True, help='Firmware image path')
    parser.add_argument('--deep', action='store_true', help='Deep scan (includes CVE lookup)')
    parser.add_argument('--output', help='Output report file (.json or .html)', default='report.json')
    args = parser.parse_args()

    firmware_path = args.firmware
    if not os.path.exists(firmware_path):
        print('[!] Firmware file not found')
        return

    print('[*] Starting extraction...')
    work_dir = 'output_firmware'
    if os.path.exists(work_dir):
        shutil.rmtree(work_dir)
    os.makedirs(work_dir)

    extractor = FirmwareExtractor(firmware_path, work_dir)
    extractor.extract()

    print('[*] Scanning extracted file system...')
    fs_scanner = FileSystemScanner(work_dir)
    fs_results = fs_scanner.scan()

    print('[*] Analyzing binaries...')
    bin_analyzer = BinaryAnalyzer(work_dir, deep=args.deep)
    bin_results = bin_analyzer.scan()

    print('[*] Scanning for weak cryptographic keys...')
    crypto_scanner = CryptoScanner(work_dir)
    crypto_results = crypto_scanner.scan()

    print('[*] Parsing init/network configurations...')
    net_parser = NetworkServiceParser(work_dir)
    net_results = net_parser.scan()

    firmware_hash = hash_file(firmware_path)

    report = {
        'firmware_hash': firmware_hash,
        'filesystem_findings': fs_results,
        'binary_findings': bin_results,
        'crypto_findings': crypto_results,
        'network_services': net_results
    }

    print(f'[*] Generating report: {args.output}')
    reporter = ReportGenerator()
    if args.output.endswith('.html'):
        reporter.generate_html(report, args.output)
    else:
        reporter.generate_json(report, args.output)

    print('[+] Analysis complete.')

if __name__ == '__main__':
    main()
