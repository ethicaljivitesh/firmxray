import os
import re

class CryptoScanner:
    def __init__(self, root_dir):
        self.root_dir = root_dir

    def scan(self):
        weak_keys = []
        for root, _, files in os.walk(self.root_dir):
            for file in files:
                if file.endswith((".pem", ".crt", ".key")):
                    full_path = os.path.join(root, file)
                    weak_keys.append(full_path)
        return weak_keys
