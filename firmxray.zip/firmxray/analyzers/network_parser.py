import os

class NetworkServiceParser:
    def __init__(self, root_dir):
        self.root_dir = root_dir

    def scan(self):
        services = []
        for root, _, files in os.walk(self.root_dir):
            for file in files:
                if file in ['inetd.conf', 'init.d', 'rc.local']:
                    full_path = os.path.join(root, file)
                    try:
                        with open(full_path, 'r', errors='ignore') as f:
                            data = f.read()
                            if "telnet" in data or "ftp" in data:
                                services.append({"file": full_path, "content": data.strip()[:200]})
                    except:
                        continue
        return services

