import os
import re

class FileSystemScanner:
    def __init__(self, root_dir):
        self.root_dir = root_dir

    def scan(self):
        results = {"default_creds": [], "sensitive_files": []}
        for root, _, files in os.walk(self.root_dir):
            for file in files:
                full_path = os.path.join(root, file)
                if file in ['passwd', 'shadow', 'config.xml']:
                    results["sensitive_files"].append(full_path)
                if file.endswith(".conf"):
                    with open(full_path, errors='ignore') as f:
                        content = f.read()
                        if "root:" in content or "admin:" in content:
                            results["default_creds"].append(full_path)
        return results
