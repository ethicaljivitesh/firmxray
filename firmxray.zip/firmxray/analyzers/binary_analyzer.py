import os
import subprocess

class BinaryAnalyzer:
    def __init__(self, root_dir, deep=False):
        self.root_dir = root_dir
        self.deep = deep

    def scan(self):
        results = []
        for root, _, files in os.walk(self.root_dir):
            for file in files:
                full_path = os.path.join(root, file)
                try:
                    output = subprocess.check_output(['file', full_path]).decode()
                    if 'ELF' in output:
                        findings = {"path": full_path, "type": output.strip()}
                        if self.deep:
                            findings["checksec"] = subprocess.getoutput(f"checksec --file={full_path}")
                        results.append(findings)
                except Exception:
                    continue
        return results
