import subprocess
import os

class FirmwareExtractor:
    def __init__(self, firmware_path, output_dir):
        self.firmware_path = firmware_path
        self.output_dir = output_dir

    def extract(self):
        print(f"[*] Running binwalk with root privileges...")
        try:
            result = subprocess.run(
                ["sudo", "binwalk", "-e", "--run-as=root", "--directory", self.output_dir, self.firmware_path],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            if result.returncode == 0:
                print("[+] Binwalk extraction complete.")
            else:
                print("[!] Binwalk exited with non-zero code.")
        except FileNotFoundError:
            print("[!] Binwalk not found. Install it via: sudo apt install binwalk")
        except subprocess.CalledProcessError as e:
            print(f"[!] Binwalk failed:\n{e.stderr.decode(errors='ignore')}")

